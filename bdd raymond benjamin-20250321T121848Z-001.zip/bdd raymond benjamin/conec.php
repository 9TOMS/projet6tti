<?php
$bdd = mysqli_connect('localhost','root','','utilisateurs'); // Correction du nom de la base de données

if (!$bdd) {
    die("Connection failed: " . mysqli_connect_error());
}

if (!mysqli_set_charset($bdd, "utf8")) {
    echo "Erreur lors du chargement du jeu de caractères utf8 : ", mysqli_error($bdd);
    exit();
}
?>