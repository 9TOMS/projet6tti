<?php
define('PREFIX_SALT', 'ççaaaa111222333');
define('SUFFIX_SALT', 'ççbbbb444555666');

// Connexion à la base de données
$bdd = mysqli_connect('localhost', 'root', '', 'utilisateurs');
if (!mysqli_set_charset($bdd, "utf8")) {
    echo "Erreur lors du chargement du jeu de caractères utf8 : ", mysqli_error($bdd);
    exit();
}
if (!$bdd) {
    die("Connection failed: " . mysqli_connect_error());
}

// Vérification des informations de connexion
if (isset($_POST["Valider"])) {
    $Pseudo_Utilisateur = $_POST['Pseudo'];
    $Mot_de_passe_Utilisateur = $_POST['MDP'];

    if (empty($Pseudo_Utilisateur) || empty($Mot_de_passe_Utilisateur)) {
        $message = "Vous devez entrer votre pseudo et votre mot de passe !";
    } else {
        // Récupérer le mot de passe haché depuis la base de données
        $sql = "SELECT Mot_de_passe_Utilisateur, statut FROM utilisateurs WHERE Pseudo_Utilisateur = '$Pseudo_Utilisateur'";
        $result = mysqli_query($bdd, $sql);
        if ($result && $row = mysqli_fetch_assoc($result)) {
            $Mot_de_passe_Hash = $row['Mot_de_passe_Utilisateur'];
            // Vérifier si le mot de passe fourni correspond au hachage stocké
            if (password_verify(PREFIX_SALT.$Mot_de_passe_Utilisateur.SUFFIX_SALT, $Mot_de_passe_Hash)) {
                // Démarrage de la session
                session_start();

                // Attribution du pseudo à la session
                $_SESSION['prenom'] = $Pseudo_Utilisateur;

                // Création des cookies pour le pseudo et le mot de passe
                setcookie('pseudo', $Pseudo_Utilisateur, time() + 365*24*3600, '/');
                // Ne stocke pas le mot de passe en clair dans un cookie
                // setcookie('MDP', $Mot_de_passe_Utilisateur, time() + 365*24*3600, '/');

                // Vérification du statut admin
                if ($row['statut'] === 'admin') {
                    header('Location: connectedadmin.php');
                } else {
                    header('Location: connected.php');
                }
                exit();
            } else {
                // Mot de passe incorrect
                $message = "Le pseudo ou le mot de passe est incorrect";
            }
        } else {
            // Utilisateur non trouvé dans la base de données
            $message = "Le pseudo ou le mot de passe est incorrect";
        }
    }
}

// Affichage du formulaire de connexion
echo '
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <style>
        /* Styles CSS */
    </style>
</head>
<body>
    <form action="index.php" method="post">
        <fieldset>
            <legend>Connectez-vous</legend>';
            if (isset($message)) {
                echo "<p class='rouge'>".$message."</p>";
            }
            echo '
            <p>
                <label for="Pseudo">Pseudo : </label>
                <input type="text" id="Pseudo" name="Pseudo">
            </p>
            <p>
                <label for="MDP">Mot de passe : </label>
                <input type="password" id="MDP" name="MDP">
            </p>
            <p class="centre">
                <input type="submit" value="Valider" name="Valider">
            </p>
        </fieldset>
    </form>
</body>
</html>';
?>
