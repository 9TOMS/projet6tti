<?php
    session_start();
        
    if (isset($_SESSION['prenom'])){
        echo "<h1>Bienvenue, " . $_SESSION['prenom'] . "</h1>";
    }
?>