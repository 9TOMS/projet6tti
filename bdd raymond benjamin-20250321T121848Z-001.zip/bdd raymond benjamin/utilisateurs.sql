-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : mar. 04 juin 2024 à 11:14
-- Version du serveur :  5.7.29
-- Version de PHP : 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `utilisateurs`
--

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `Id_Utilisateur` int(10) UNSIGNED NOT NULL,
  `Nom_Utilisateur` varchar(30) DEFAULT NULL,
  `Prenom_Utilisateur` varchar(30) DEFAULT NULL,
  `Mail_Utilisateur` varchar(50) NOT NULL,
  `Pseudo_Utilisateur` varchar(20) NOT NULL,
  `Mot_de_passe_Utilisateur` varchar(100) NOT NULL,
  `statut` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`Id_Utilisateur`, `Nom_Utilisateur`, `Prenom_Utilisateur`, `Mail_Utilisateur`, `Pseudo_Utilisateur`, `Mot_de_passe_Utilisateur`, `statut`) VALUES
(4, 'Vaillant', 'Michel', 'michel.vaillant.el@pierrard.eu', 'vaimie', '$2y$10$zmQ3UJYcWGjTMAQJ9zcsau5Fndg6n3IYHChR3Rgf/ak63z9Ev1nhm', 'users'),
(9, 'Raymond', 'Benjamin', 'benjy.be@gmail.com', 'raybe', '$2y$10$7OWi3XxBNVv/OWZhCFIlzO3oNvaggi6il8PFa4AzcJRoaVYkTLmQy', 'admin'),
(12, 'Richard', 'Maxime', 'maxime.richard.el@pierrard.eu', 'ricma', '$2y$10$34b1eJW8ymxdAJbXg8dLjeJ4qWLw.hBf/4CqWJC9cMsA1oHrgAIUy', 'users'),
(13, 'Raty', 'Mael', 'mael.raty.el@pierrard.eu', 'mamaa', '$2y$10$oRikc86GoTZJT7B29KXMlehEZHoOgvoxhx3Uzld/HtHRKZqoX1d1e', 'users'),
(18, 'Schrobi', 'Tom', 'tom@gmail.com', 'tomsch', '$2y$10$z.rI74O5on2I0a.zjy2RJONDg.HtPS0O0RvaDfEHS2sRh8da4j9.C', 'users'),
(22, 'Berthelemy', 'Celestin', 'celber@gmail.com', 'celber', '$2y$10$GxC4qGZzExzpHkzj3Cte7.iSP3bbrP6GeoQ2dMHfaDKkj0CdQ0jhm', 'users');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`Id_Utilisateur`),
  ADD UNIQUE KEY `Psuedo_Utilisateur` (`Pseudo_Utilisateur`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  MODIFY `Id_Utilisateur` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
