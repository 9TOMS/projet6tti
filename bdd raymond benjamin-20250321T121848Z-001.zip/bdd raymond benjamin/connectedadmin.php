<?php
// Assurez-vous que $bdd est défini et connecté à la base de données
$bdd = mysqli_connect('localhost','root','','utilisateurs');
if (!$bdd) {
    die("Connection failed: " . mysqli_connect_error());
}
if (!mysqli_set_charset($bdd, "utf8")) {

    echo "Erreur lors du chargement du jeu de caractères utf8 : ", mysqli_error($bdd);
 
    exit();
 
 }
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Utilisateurs</title>
</head>

<body>
    <fieldset>
        <h2>Ajouter un Utilisateur</h2>
        <form method="post" action="">
            <label for="nom">Nom:</label><br>
            <input type="text" id="nom" name="nom" required><br>
            <label for="prenom">Prénom:</label><br>
            <input type="text" id="prenom" name="prenom" required><br>
            <label for="mail">Mail:</label><br>
            <input type="email" id="mail" name="mail" required><br>
            <label for="pseudo">Pseudo:</label><br>
            <input type="text" id="pseudo" name="pseudo" required><br>
            <label for="mdp">Mot de passe:</label><br>
            <input type="password" id="mdp" name="mdp" required><br><br>
            <input type="submit" value="Ajouter Utilisateur" name="ajouter_utilisateur">
        </form>
    </fieldset>

    <?php
    define('PREFIX_SALT', 'ççaaaa111222333');

    define('SUFFIX_SALT', 'ççbbbb444555666');

    if(isset($_POST['ajouter_utilisateur'])) {
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $mail = $_POST['mail'];
        $pseudo = $_POST['pseudo'];
        $mdp = $_POST['mdp'];
        $role = "user";
        $hashSecure = password_hash(PREFIX_SALT.$mdp.SUFFIX_SALT,PASSWORD_DEFAULT);
        $insert_query = "INSERT INTO utilisateurs (Nom_Utilisateur, Prenom_Utilisateur, Mail_Utilisateur, Pseudo_Utilisateur, Mot_de_passe_Utilisateur, statut) VALUES ('$nom', '$prenom', '$mail', '$pseudo', '$hashSecure','users')";

        if(mysqli_query($bdd, $insert_query)) {
            echo "<script>alert('Utilisateur ajouté avec succès');</script>";
            echo "<meta http-equiv='refresh' content='0'>"; // Actualiser la page après ajout
        } else {
            echo "Erreur lors de l'ajout de l'utilisateur : " . mysqli_error($bdd);
        }
    }?>
    <fieldset>
        <h2>Modifier un Utilisateur</h2>
        <form method="post" action="" name="choixutil">
            <label for="utilisateur">Sélectionner un utilisateur :</label><br>
            <select id="utilisateur" name="utilisateur" onchange="valideUtilisateur()">
                <?php

                $requete_utilisateurs = "SELECT Id_Utilisateur, Nom_Utilisateur, Prenom_Utilisateur, Mail_Utilisateur, Pseudo_Utilisateur, Mot_de_passe_Utilisateur FROM utilisateurs WHERE statut='users'";
                $resultat_utilisateurs = mysqli_query($bdd, $requete_utilisateurs);
                $premier=True;
                if ($resultat_utilisateurs) {
                    while ($row = mysqli_fetch_assoc($resultat_utilisateurs)) {
                        if ($premier==True){
                            $premier=FALSE;
                            $selectedUserId = isset($_POST['utilisateur']) ? $_POST['utilisateur']:$row['Id_Utilisateur']; // Sauvegarde de la valeur sélectionnée
                            $nom_utilisateur = $row['Nom_Utilisateur'];
                            $prenom_utilisateur = $row['Prenom_Utilisateur'];
                            $mail_utilisateur = $row['Mail_Utilisateur'];
                            $pseudo_utilisateur = $row['Pseudo_Utilisateur'];
                            $mdp_utilisateur = $row['Mot_de_passe_Utilisateur'];
                        }
                        echo "<option value='{$row['Id_Utilisateur']}'";
                        if ($selectedUserId == $row['Id_Utilisateur']) {
                            echo " selected"; // Sélectionner l'option si elle correspond à la valeur sauvegardée
                        }
                        echo ">{$row['Nom_Utilisateur']} {$row['Prenom_Utilisateur']}</option>";
                    }
                    mysqli_free_result($resultat_utilisateurs);
                }
            echo('</select><br><br>');
        echo('</form>');
        $idutil =(isset($_POST['utilisateur']))?$_POST['utilisateur']:$selectedUserId;
                $requete = "SELECT Id_Utilisateur, Nom_Utilisateur, Prenom_Utilisateur, Mail_Utilisateur, Pseudo_Utilisateur, Mot_de_passe_Utilisateur FROM utilisateurs WHERE Id_Utilisateur=$idutil";
                $requeteresult = mysqli_query($bdd, $requete);
                $requetevalue = mysqli_fetch_assoc($requeteresult);
                $idutil2 = $requetevalue['Id_Utilisateur'];
                $nom_utilisateur = $requetevalue['Nom_Utilisateur'];
                $prenom_utilisateur = $requetevalue['Prenom_Utilisateur'];
                $mail_utilisateur = $requetevalue['Mail_Utilisateur'];
                $pseudo_utilisateur = $requetevalue['Pseudo_Utilisateur'];
                $mdp_utilisateur = $requetevalue['Mot_de_passe_Utilisateur'];
                ?>

        <form method="post" action="" name="modifierutil">   
            <!-- Champs pour modifier les données -->
            <label for="nom_modif">Nom:</label><br>
            <input type="text" id="nom_modif" name="nom_modif" value='<?php echo $nom_utilisateur; ?>' required><br>
            <label for="prenom_modif">Prénom:</label><br>
            <input type="text" id="prenom_modif" name="prenom_modif" value='<?php echo $prenom_utilisateur; ?>' required><br>
            <label for="mail_modif">Mail:</label><br>
            <input type="email" id="mail_modif" name="mail_modif" value='<?php echo $mail_utilisateur; ?>' required><br>
            <label for="pseudo_modif">Pseudo:</label><br>
            <input type="text" id="pseudo_modif" name="pseudo_modif" value='<?php echo $pseudo_utilisateur; ?>' required><br>
            <label for="mdp_modif">Mot de passe:</label><br>
            <input type="password" id="mdp_modif" name="mdp_modif"><br><br>
            <input type="hidden" name="id" value='<?php echo  $idutil2; ?>'> 
            <input type="submit" value="Modifier Utilisateur" name="modifier_utilisateur">
        </form>
    </fieldset>

    
<?php
if (isset($_POST['modifier_utilisateur'])) {
    $id_utilisateur = $_POST['id'] ; // Récupérer l'ID de l'utilisateur sélectionné depuis le formulaire
    // Récupérer les autres champs du formulaire
    $nom_modif = $_POST['nom_modif'];
    $prenom_modif = $_POST['prenom_modif'];
    $mail_modif = $_POST['mail_modif'];
    $pseudo_modif = $_POST['pseudo_modif'];
    $mdp_modif = $_POST['mdp_modif'];
    $hashSecure = password_hash(PREFIX_SALT.$mdp_modif.SUFFIX_SALT,PASSWORD_DEFAULT);
    // Construire la requête de mise à jour en utilisant l'ID de l'utilisateur récupéré

    if(($_POST['mdp_modif'])!== ''){
        $modifier_query = "UPDATE utilisateurs SET Nom_Utilisateur = '$nom_modif', Prenom_Utilisateur = '$prenom_modif', Mail_Utilisateur = '$mail_modif', Pseudo_Utilisateur = '$pseudo_modif', Mot_de_passe_Utilisateur = '$hashSecure' WHERE Id_Utilisateur = $id_utilisateur";
    
    }else {
        $modifier_query = "UPDATE utilisateurs SET Nom_Utilisateur = '$nom_modif', Prenom_Utilisateur = '$prenom_modif', Mail_Utilisateur = '$mail_modif', Pseudo_Utilisateur = '$pseudo_modif' WHERE Id_Utilisateur = $id_utilisateur";
    }

    // Exécuter la requête de mise à jour
    if (mysqli_query($bdd, $modifier_query)) {
        echo "<script>alert('Utilisateur modifié avec succès');</script>";
        echo "<meta http-equiv='refresh' content='0'>"; // Actualiser la page après modification
    } else {
        echo "Erreur lors de la modification de l'utilisateur : " . mysqli_error($bdd);
    }
}
?>
    <fieldset>
    <h2>Liste des Utilisateurs</h2>
    <table style='border-style: solid;'>
        <tr>
            <th style='border: solid 1px;'>Nom</th>
            <th style='border: solid 1px;'>Prénom</th>
            <th style='border: solid 1px;'>Mail</th>
            <th style='border: solid 1px;'>Pseudo</th>
            <th style='border: solid 1px;'>Statut</th>
            <th style='border: solid 1px;'>Action</th>
        </tr>

        <?php
        // Exécute la requête SQL pour récupérer les utilisateurs
        $requete = "SELECT * FROM utilisateurs";
        $resultat = mysqli_query($bdd, $requete);
        
        // Vérifie si la requête a réussi
        if ($resultat) {
            // Affiche chaque utilisateur dans le tableau
            while ($row = mysqli_fetch_assoc($resultat)) {
                echo "<tr>
                          <td style='border: solid 1px;'>{$row['Nom_Utilisateur']}</td>
                          <td style='border: solid 1px;'>{$row['Prenom_Utilisateur']}</td>
                          <td style='border: solid 1px;'>{$row['Mail_Utilisateur']}</td>
                          <td style='border: solid 1px;'>{$row['Pseudo_Utilisateur']}</td>
                          <td style='border: solid 1px;'>{$row['statut']}</td>
                          <td style='border: solid 1px;'>  
                            <form method='post' action='' name='supp".$row['Id_Utilisateur']."'>
                                <input type='hidden' name='id_utilisateur' value='{$row['Id_Utilisateur']}'>
                                <input type='hidden' name='statut' value='{$row['statut']}'>
                                <input type='button' value='Supprimer' onclick='valider(\"supp".$row['Id_Utilisateur']."\")' name='delete' >
                            </form>
                          </td>
                      </tr>";
            }
            mysqli_free_result($resultat); // Libère la mémoire du résultat
        } else {
            echo "<tr><td colspan='6'>Erreur lors de la récupération des utilisateurs : " . mysqli_error($bdd) . "</td></tr>";
        }

        if(isset($_POST['statut'])) {
            $id_utilisateur = $_POST['id_utilisateur'];
            $statut_utilisateur = $_POST['statut'];
            // Vérifie si l'utilisateur a le statut d'administrateur
            if ($statut_utilisateur == 'admin') {
                echo "<script>alert('La suppression des administrateurs est impossible');</script>";
            } else {
                $delete_query = "DELETE FROM utilisateurs WHERE Id_Utilisateur = $id_utilisateur";
                if(mysqli_query($bdd, $delete_query)) {
                    echo "<script>alert('Utilisateur supprimé avec succès');</script>";
                    echo "<meta http-equiv='refresh' content='0'>"; // Actualiser la page après suppression
                } else {
                    echo "Erreur lors de la suppression de l'utilisateur : " . mysqli_error($bdd);
                }
            }
        }
        mysqli_close($bdd); // Ferme la connexion à la base de données
        ?>
    </table>
    <script>
        function valideUtilisateur() {
            document.forms['choixutil'].submit();
        }
        function valider(formulaire){
            if (confirm ('Etes vous sur de vouloir supprimer cet utilisateur ?')){
            document.forms[formulaire].submit();
            }
        }
    </script>
</body>
</html>