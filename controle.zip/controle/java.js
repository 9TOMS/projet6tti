let nbr_max=1024 ,nbr_aleatoire=Math.floor(Math.random() * (nbr_max) ),nbr_coup=0;
function test() {
    let nbr = document.getElementById('nbr');
    nbr = nbr.value;
    nbr_coup=nbr_coup+1;
    if (nbr==nbr_aleatoire){
        document.getElementById('text2').innerHTML="Vous avez trouvé la solution en "+nbr_coup+" coups";
        document.getElementById('text1').innerHTML="Standing ovation";
        document.documentElement.style.setProperty('--couleur','yellow');
        document.documentElement.style.setProperty('--bordure','15px solid var(--couleur)');
        document.documentElement.style.setProperty('--couleur2_fond','yellow');
    } else {
        if (nbr>nbr_aleatoire){
            document.getElementById('text2').innerHTML="Le nombre à trouver est plus petit";
            document.documentElement.style.setProperty('--couleur','red');
            document.documentElement.style.setProperty('--bordure','15px solid var(--couleur)');
        } else {
            if (nbr<nbr_aleatoire){
                document.getElementById('text2').innerHTML="Le nombre à trouver est plus grand";
                document.documentElement.style.setProperty('--couleur','green');
                document.documentElement.style.setProperty('--bordure','15px solid var(--couleur)');
            }
        }
    }
}