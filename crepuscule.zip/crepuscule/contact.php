<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Le site officiel de l'ASBL Crépuscule à Sommethonne.">
    <meta name="Pierrard" content="Les éleves de Pierrard">
    <meta name="theme-color" content="#C8F6D9BF">
    <meta property="og:title" content="Contact - ASBL Crépuscule">
    <meta property="og:description"
        content="Site officiel de l'ASBL Crépuscule, organisant des activités à Sommethonne et ses alentours.">
    <meta property="og:image" content="http://localhost/crepuscule/images/logo.png">
    <meta property="og:url" content="http://localhost/crepuscule/contact.php">
    <meta property="og:type" content="website">
    <link rel="icon" href="images/logo.png" type="image/png">
    <script defer src="java.js"></script>
    <title>Contact - Crépuscule</title>
</head>
<body>
    <?php include("entete.php"); ?>
    <div id="corps">
        <div class="page3">
            <?php include("menu.php"); ?>
            <div id="contact">
                <h1 id="titre_nom_contact">Contactez-nous</h1>
                <div id="MethodeDeContact">
                    <section id="ensemble_contact">
                        <a rel="noopener noreferrer" target="_blank" id="telephone" href="tel:+32476949360">
                            <img alt="Téléphone" id="ImageTelephone" src="images/gsm.png">
                            <h2 id="petit_titre_contact">Par téléphone</h2>
                            <p id="info_text">0476 94 93 60</p>
                        </a>
                        <a rel="noopener noreferrer" target="_blank" id="mail" href="mailto:crepusculeasbl@gmail.com">
                            <img alt="Mail" id="ImageMail" src="images/mail.PNG">
                            <h2 id="petit_titre_contact">Par mail</h2>
                            <p id="info_text">crepusculeasbl@gmail.com</p>
                        </a>
                    </section>
                    <section id="ensemble_contact">
                        <a rel="noopener noreferrer" target="_blank" id="facebook" href="https://www.facebook.com/asblcrepuscule">
                            <img alt="Facebook" id="ImageFacebook" src="images/facebook.png">
                            <h2 id="petit_titre_contact">Par facebook</h2>
                            <p id="info_text">asblcrepuscule</p>
                        </a>
                        <div id="localisation" title="Carte Google Maps - Localisation de Crépuscule">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m21!1m12!1m3!1d4917.709826627782!2d5.449617939099516!3d49.58171646530822!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m6!3e2!4m0!4m3!3m2!1d49.58437365332589!2d5.45127017993111!5e1!3m2!1sfr!2sbe!4v1744975054448!5m2!1sfr!2sbe"
                             width="250" height="250" style="border:0;" allowfullscreen="" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>
                            <h2 id="petit_titre_contact">Retrouvez nous ici</h2>

                        </div>
                    </section>

                </div>
            </div>
        </div>
    </div>
    <?php include("pied_de_page.php"); ?>
    </body>
    </html>