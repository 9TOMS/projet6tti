<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Le site officiel de l'ASBL Crépuscule à Sommethonne." />
    <meta name="Pierrard" content="Les élèves de Pierrard" />
    <meta name="theme-color" content="#C8F6D9BF" />
    <meta property="og:title" content="Tarif - ASBL Crépuscule" />
    <meta property="og:description" content="Site officiel de l'ASBL Crépuscule, organisant des activités à Sommethonne et ses alentours." />
    <meta property="og:image" content="http://localhost/crepuscule/images/logo.png" />
    <meta property="og:url" content="http://localhost/crepuscule/tarif.php" />
    <meta property="og:type" content="website" />
    <link rel="icon" href="images/logo.png" type="image/png" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet" />
    <script defer src="java.js"></script>
    <title>Tarif - Crépuscule</title>
    <style>
        /* Carrousel flèches */
        .carousel {
            position: relative;
            /* Pour positionner les flèches par rapport au carrousel */
            width: 100%;
            height: 435px;
            margin: 10px auto;
            overflow: hidden;
            border-radius: 25px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            background-color: rgba(255, 255, 255, 0.8);
        }

        .carousel-items {
            display: flex;
            transition: transform 0.5s ease-in-out;
            width: 100%;
            height: 100%;
        }

        .carousel-item {
            min-width: 100%;
            height: 100%;
            color: #333;
            background-color: rgba(0, 0, 0, 0.1);
            border-radius: 25px;
        }

        .stage_taille {
            padding-left: 50px;
            padding-right: 50px;
        }

        /* Styles pour les flèches */
        .carousel-arrow {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background-color: rgba(0, 0, 0, 0.5);
            color: white;
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            font-size: 1.5rem;
            cursor: pointer;
            z-index: 10;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .carousel-arrow.left {
            left: 10px;
        }

        .carousel-arrow.right {
            right: 10px;
        }

        .carousel-arrow:hover {
            background-color: rgba(0, 0, 0, 0.7);
        }

        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            background-color: #f9f9f9;
            color: #333;
        }

        h1 {
            text-align: center;
            color: #2c3e50;
        }

        section {
            background: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .bleu {
            color: #2980b9;
            margin-bottom: 15px;
            text-align: center;
        }

        ul {
            padding-left: 20px;
        }

        .important {
            background: #ffe9e9;
            padding: 10px;
            border-left: 4px solid #e74c3c;
            margin: 15px 0;
        }

        .prix {
            font-weight: bold;
            color: #27ae60;
        }
    </style>
</head>

<body>
    <?php include("entete.php"); ?>

    <div class="page">
        <?php include("menu.php"); ?>
        <div id="page5">
            <!-- Colonne des stages -->
            <div class="colonnestages">
                <div id="titre_formulaire">Formulaires Stages</div>

                <div class="carousel">
                    <div class="carousel-items">
                        <?php
                        $color = ['lightcoral', 'lightseagreen', 'lightblue'];
                        for ($i = 1; $i < 4; $i++) {
                            ?>
                            <div class="carousel-item" style="background-color: <?php echo $color[$i - 1]; ?>;">
                                <form id="form-stage<?php echo $i; ?>">
                                    <h2>Stage <?php echo $i; ?></h2>
                                    <div id="centre"> Pour voir le stage click ici</div>
                                    <div class="stage_taille">
                                        <br><label for="nom">Nom :</label>
                                        <input type="text" id="nom" name="nom" required>
                                        <label for="prenom">Prénom :</label>
                                        <input type="text" id="prenom" name="prenom" required>
                                        <label for="email">Email :</label>
                                        <input type="email" id="email" name="email" required>
                                        <label for="nombredepersonne">Nombre de personne :</label>
                                        <input type="number" id="nombredepersonne" name="nombredepersonne" min="1" required>
                                        <button type="submit">S'inscrire</button>
                                    </div>
                                </form>
                            </div>
                        <?php } ?>
                    </div>
                    <!-- Flèche gauche -->
                    <button id="carousel-arrow-tarif" class="carousel-arrow left">&lt;</button>
                    <!-- Flèche droite -->
                    <button id="carousel-arrow-tarif" class="carousel-arrow right">&gt;</button>
                </div>


            </div>
            <!-- Colonne formulaire des cours -->
            <div class="colonnecours">
                <div id="titre_formulaire">Cours, Balade et autre</div>

                <h3 class="bleu">Cours en groupe</h3>
                <p>Un cours coûte <span class="prix">25 €</span>. <strong>Note :</strong> l’inscription est réservée aux
                    <strong>membres uniquement</strong>.</p>
                <p>Nous proposons également une <strong>carte de 10 cours</strong> au prix avantageux de <span
                        class="prix">200 €</span>.</p>
                <h3 class="bleu">Balades</h3>
                <p>Nous organisons des <strong>balades de 2 heures</strong> pour <span class="prix">40 €</span>,
                    accessibles à tous les niveaux.</p>
                <h3 class="bleu">Événements personnalisés</h3>
                <p>Vous pouvez également fêter un anniversaire ou organiser une activité sur mesure.</p>
                <p>Il suffit de nous contacter <a href="contact.php">en cliquant ici</a></p>
                <p><strong>Exemples d’activités :</strong>Remise en selle,Baby poney,Balade en attelage,Journée
                    événementielle,...</p>

                <h3 class="bleu">Informations importantes</h3>
                <ul>
                    <li><strong>Équipement recommandé :</strong> pantalon long et bottes. <em>Les baskets sont
                            interdites.</em></li>
                    <li><strong>Réservations :</strong> via la page <strong>Agenda</strong>, au moins <strong>24h à
                            l’avance</strong>, pour les cours comme pour les annulations.</li>
                </ul>

            </div>
        </div>
    </div>
    <?php include("pied_de_page.php"); ?>
    <script>
        const carouselContainer = document.querySelector('.colonnestages .carousel-items');
        const leftArrow = document.querySelector('.carousel-arrow.left');
        const rightArrow = document.querySelector('.carousel-arrow.right');
        let currentIndex = 0;
        let coter = 50;

        if (carouselContainer) {
            currentIndex = 0;

            function updateCarousel() {
                const totalItems = carouselContainer.children.length;
                const offset = -currentIndex * 100;
                carouselContainer.style.transform = `translateX(${offset}%)`;
            }

            function showNextSlide() {
                const totalItems = carouselContainer.children.length;
                currentIndex = (currentIndex + 1) % totalItems;
                updateCarousel();
            }

            function showPreviousSlide() {
                const totalItems = carouselContainer.children.length;
                currentIndex = (currentIndex - 1 + totalItems) % totalItems;
                updateCarousel();
            }

            // Naviguer avec les flèches
            rightArrow.addEventListener('click', showNextSlide);
            leftArrow.addEventListener('click', showPreviousSlide);
        }
    </script>
</body>

</html>