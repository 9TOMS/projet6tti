<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
    <script defer src="java.js"></script>
</head>
<body>
<?php include("entete.php"); ?>
<div class="page3">
    <?php include("menu.php"); ?>
    <div id="agenda">
        <iframe class="calendrier" 
        src="https://calendar.google.com/calendar/embed?src=c_c38ae909f0a3613063b22d33e76bb284a7face46e0fcc61d84d3d5fc188b2e6d%40group.calendar.google.com&ctz=Europe%2FBrussels" 
            style="border:solid 1px #777; border-radius:15px" style="borderradius: 30;" width="1100" height="auto" frameborder="0" scrolling="no">
        </iframe>
    </div>
    
</div>
<?php include("pied_de_page.php"); ?>
</body>
</html>