<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
    <script defer src="java.js"></script>
</head>
<body>
<?php include("entete.php"); ?>
<div class="page">
    <?php include("menu.php"); ?>
    <div id="agenda">
        <iframe class="calendrier" 
            src="https://calendar.google.com/calendar/embed?height=600&wkst=2&ctz=Europe%2FBrussels&showPrint=0&mode=MONTH&hl=fr&title=test&src=bWFkb21hZ2UxMjI3ZGRAZ21haWwuY29t&src=YWRkcmVzc2Jvb2sjY29udGFjdHNAZ3JvdXAudi5jYWxlbmRhci5nb29nbGUuY29t&src=YTRmZjc1NWYzNzc5NDU1NjI5ODU2Y2YzODZmNmNmMDU2NDU4MzExZDdmZGM4MGIxM2M3ZDlhMDkxMzliZmM5NUBncm91cC5jYWxlbmRhci5nb29nbGUuY29t&src=ZnIuYmUjaG9saWRheUBncm91cC52LmNhbGVuZGFyLmdvb2dsZS5jb20&src=Y2xhc3Nyb29tMTExMDc4MTM2NDQ1NDg4NjM4MDEyQGdyb3VwLmNhbGVuZGFyLmdvb2dsZS5jb20&color=%23039BE5&color=%2333B679&color=%23AD1457&color=%230B8043&color=%23202124" 
            style="border:solid 1px #777; border-radius:15px" style="borderradius: 30;" width="1100" height="auto" frameborder="0" scrolling="no">
        </iframe>
    </div>
    
</div>
<?php include("pied_de_page.php"); ?>
</body>
</html>