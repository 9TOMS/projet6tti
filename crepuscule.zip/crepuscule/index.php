<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil</title>
    <script defer src="java.js"></script>
</head>

<style>
    .news-item2 {
        margin-top: 17px;
        width: calc(100vw - 520px);
        height: auto;
    }
</style>
<body>
    <?php include("entete.php"); ?>
    <div class="page_index2">
        <?php include("menu.php"); ?>
        <div id="page_index">
            <?php $bdd = mysqli_connect('localhost', 'root', '', 'crepuscule');
            $query = "SELECT Id_News, Photo_News, Info_News, Date_News FROM news ORDER BY Id_News DESC";
            $result = mysqli_query($bdd, $query);
            // Parcourir toutes les news disponibles
            while ($row = mysqli_fetch_assoc($result)) {
                $id = $row['Id_News'];
                $imagenews = $row['Photo_News'];
                $titrenews = $row['Info_News'];
                $datenews = $row['Date_News'];
                ?>
                <div class="news-item2" id="news-0">
                    <div class="news_poste marge">
                        <div class="top">
                        <div class="gauche"><?php echo($titrenews)?></div>
                        <div class="droite"><?php echo($datenews);?></div>
                        </div>
                        <div class="imagenews pdfnews-container calendar-container iframe-shadow">
                            <?php
                            $embedUrl = str_replace('/pub?', '/embed?', $imagenews);
                            ?>
                            <iframe src="<?php echo htmlspecialchars($embedUrl); ?>" frameborder="0" class="pdfnews2"
                                id="pdfnews2" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"
                                width="100%"></iframe>
                        </div>
                        <div class="bas">
                            <div class="coeur">❤️</div>
                            <div class="partage">➤</div>
                        </div>
                    </div>
                </div>
            <?php break;
            } ?>

            <div class="info_acceuil">
                <div class="activites_acceuil">
                    <h3>Activités</h3>
                    <p>Prochaine activitée :</p>
                    <p>Nom de l'activitée :</p>
                    <p>Date de l'activité :</p>
                    <p>Nombre de places restantes :</p>
                </div>
                <div class="contact_accueil">
                    <h3>Contact</h3>
                    <p>N° tel : <a target="_blank" href="tel:+0476 94 93 60"> 0460 565 420</a></p>
                    <p>Email : <a target="_blank" href="mailto:claudelheh@gmail.com">claudelheh@gmail.com</a></p>
                    <p>Facebook: <a target="_blank" href="https://www.facebook.com/asblcrepuscule">Crépuscule</a></p>
                </div>
            </div>
        </div>
    </div>
    <?php include("pied_de_page.php"); ?>
</body>

</html>