<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Le site officiel de l'ASBL Crépuscule à Sommethonne." />
    <meta name="Pierrard" content="Les élèves de Pierrard" />
    <meta name="theme-color" content="#C8F6D9BF" />
    <meta property="og:title" content="Accueil - ASBL Crépuscule" />
    <meta property="og:description"
        content="Site officiel de l'ASBL Crépuscule, organisant des activités à Sommethonne et ses alentours." />
    <meta property="og:image" content="http://localhost/crepuscule/images/logo.png" />
    <meta property="og:url" content="http://localhost/crepuscule/index.php" />
    <meta property="og:type" content="website" />
    <link rel="icon" href="images/logo.png" type="image/png" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet" />
    <script defer src="java.js"></script>
    <title>Accueil - Crépuscule</title>
</head>

<body>
    <?php include("entete.php"); ?>

    <div class="page_index2">
        <?php include("menu.php"); ?>

        <div id="page_index">
            <?php
            $bdd = mysqli_connect('localhost', 'root', '', 'crepuscule');
            if (!$bdd) {
                error_log("Erreur de connexion BDD : " . mysqli_connect_error());
                die("Erreur de connexion. Veuillez réessayer plus tard.");
            }

            $stmt = $bdd->prepare("SELECT Id_News, Photo_News, Info_News, Date_News FROM news ORDER BY Id_News DESC LIMIT 1");
            $stmt->execute();
            $result = $stmt->get_result();

            if ($row = mysqli_fetch_assoc($result)) {
                $id = $row['Id_News'];
                $imagenews = $row['Photo_News'];
                $titrenews = $row['Info_News'];
                $datenews = $row['Date_News'];
                $embedUrl = str_replace('/pub?', '/embed?', $imagenews);
                $url = "https://8af6-212-68-196-177.ngrok-free.app/crepuscule/index.php#news" . $id;
                ?>
                <div class="news-item2 news<?php echo $id; ?>" id="news-<?php echo $id; ?>">
                    <div class="news_poste marge">
                        <div class="top">
                            <div class="gauche"><?php echo htmlspecialchars($titrenews); ?></div>
                            <div class="droite"><?php echo htmlspecialchars($datenews); ?></div>
                        </div>
                        <div class="imagenews pdfnews-container calendar-container iframe-shadow">
                            <iframe src="<?php echo htmlspecialchars($embedUrl); ?>" class="pdfnews2"
                                id="pdfnews2"></iframe>
                        </div>
                        <div class="bas">
                            <div title="Mettre un like" class="coeur">❤️</div>
                            <div title="Partager la news" class="partage">➤</div>
                        </div>
                    </div>
                </div>
            <?php } ?>

            <div class="contact_accueil">
                <div class="centre_vertical">
                    <h3>Contact</h3>
                    <p>N° tel : <a href="tel:+0460565420">0460 565 420</a></p>
                    <p>Email : <a href="mailto:claudelheh@gmail.com">claudelheh@gmail.com</a></p>
                    <p>Facebook : <a target="_blank" href="https://www.facebook.com/asblcrepuscule">Crépuscule</a></p>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m21!1m12!1m3!1d4917.709826627782!2d5.449617939099516!3d49.58171646530822!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m6!3e2!4m0!4m3!3m2!1d49.58437365332589!2d5.45127017993111!5e1!3m2!1sfr!2sbe!4v1744975054448!5m2!1sfr!2sbe"
                             width="200" height="200" style="border:0;" allowfullscreen="" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </div>
    </div>

    <div id="shareModal" class="modal" style="display: none;">
        <div class="modal-content">
            <h2>Partager sur :</h2>
            <span class="close">&times;</span>
            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode($url); ?>" target="_blank"><i
                    class="fab fa-facebook-f"></i></a>
            <a href="https://twitter.com/intent/tweet?text=<?php echo urlencode($url); ?>" target="_blank"><i
                    class="fab fa-twitter"></i></a>
            <a href="https://www.facebook.com/dialog/send?link=<?php echo urlencode($url); ?>&app_id=1880369662722130&redirect_uri=<?php echo urlencode($url); ?>"
                target="_blank"><i class="fab fa-facebook-messenger"></i></a>
            <a href="sms:?&body=<?php echo urlencode($titrenews . ' ' . $url); ?>"><i class="fas fa-sms"></i></a>
            <a href="https://api.whatsapp.com/send?text=<?php echo urlencode($titrenews . ' ' . $url); ?>"
                target="_blank"><i class="fab fa-whatsapp"></i></a>
        </div>
    </div>

    <?php include("pied_de_page.php"); ?>
</body>

</html>