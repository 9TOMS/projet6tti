<footer id="pied_de_page">
    <p><a href="index.php">Accueil</a>•<a href="mentions_legales.php">Mentions légales </a>•<a href="contact.php">contact</a></p>
    <p>|<a target="_blank" title="Page Facebook de Crépuscule" rel="noopener noreferrer" href="https://www.facebook.com/asblcrepuscule">©crépuscule</a>|<a target="_blank" rel="noopener noreferrer" title="Site internet de Pierrard" href="https://pierrard.be/">©pierrard</a> </p>
</footer>