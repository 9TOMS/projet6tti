<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Photo</title>
    <script defer src="java.js"></script>
    <style>
        body {
            background-image: url(images/MenuFond.png);
            background-size: cover;
            background-attachment: fixed;
        }

        #corps {
            display: flex;

        }

        .carousel-wrapper {
            display: flex;
            justify-content: left;
            align-items: center;
            margin-bottom: 20px;
            overflow: hidden;
            width: calc(100vw - 250px);
        }

        .carousel-container {
            display: flex;
            transition: transform 0.4s ease-in-out;
        }

        .carousel_photo {
            overflow: hidden;
            border: 2px solid black;
            border-radius: 10px;
            position: relative;
            width: calc(100vw - 276px);
        }

        .carousel-track {
            display: flex;
            transition: transform 0.4s ease-in-out;
        }

        .carousel-slide {
            min-width: calc(100% / 3);
            height: 300px;
            display: flex;
            justify-content: center;
            align-items: center;
            background-size: cover;
            background-position: center;
        }

        .carousel-slide img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 10px;
        }

        .carousel-button {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background-color: rgba(0, 0, 0, 0.5);
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 50%;
            height: 35px;
            width: 35px;
            font-size: large;
        }

        .carousel-button.prev {
            left: 10px;
        }

        .carousel-button.next {
            right: 10px;
        }

        .switch-carousel-button {
            position: relative;
            color: white;
            border: none;
            cursor: pointer;
            height: 35px;
            width: 35px;
            font-size: large;
            top: 50%;
            transform: translateY(-50%);
            background-color: rgba(0, 0, 0, 0.5);
            border-radius: 50%;
        }
    </style>
</head>

<body>
    <?php include("entete.php"); ?>
    <div class="page3">
        <?php include("menu.php"); ?>
        <div><button class="switch-carousel-button prev">&#10094;</button></div>
        <div class="carousel-wrapper">
            <div class="carousel-container">
                <?php for ($i = 1; $i <= 6; $i++) { ?>
                    <div class="carousel_photo">
                        <h2>Publication <?php echo $i; ?></h2>
                        <div class="carousel-track">
                            <?php for ($j = 1; $j <= 10; $j++) { ?>
                                <div class="carousel-slide"><img src="images/test.jpg" alt="Image <?php echo $j; ?>"></div>
                            <?php } ?>
                        </div>
                        <button class="carousel-button prev">&#10094;</button>
                        <button class="carousel-button next">&#10095;</button>
                    </div>
                <?php } ?>
            </div>
        </div>

        <div><button class="switch-carousel-button next">&#10095;</button></div>
    </div>
    <?php include("pied_de_page.php"); ?>
    <script>
        // Sélection des éléments principaux
        const carouselContainer2 = document.querySelector('.carousel-container');
        const carousels = Array.from(carouselContainer2.children);
        const switchPrevButton = document.querySelector('.switch-carousel-button.prev');
        const switchNextButton = document.querySelector('.switch-carousel-button.next');

        // Index actuel du carousel
        let currentCarouselIndex = 0;

        // Fonction pour mettre à jour l'affichage du carousel (en tenant compte de l'index actuel)
        function updateCarouselDisplay() {
            const containerWidth = carousels[0].getBoundingClientRect().width;
            carouselContainer2.style.transition = "none"; // Désactiver les transitions
            carouselContainer2.style.transform = `translateX(-${currentCarouselIndex * containerWidth}px)`; // Repositionner correctement
        }

        // Écouteur pour redimensionnement de la fenêtre
        window.addEventListener('resize', () => {
            updateCarouselDisplay(); // Mise à jour basée sur l'index actuel
        });

        // Gestion des boutons de navigation (Précédent et Suivant)
        switchNextButton.addEventListener('click', () => {
            currentCarouselIndex = (currentCarouselIndex + 1) % carousels.length; // Passer au suivant
            const containerWidth = carousels[0].getBoundingClientRect().width;
            carouselContainer2.style.transition = ""; // Activer la transition
            carouselContainer2.style.transform = `translateX(-${currentCarouselIndex * containerWidth}px)`; // Repositionner
        });

        switchPrevButton.addEventListener('click', () => {
            currentCarouselIndex = (currentCarouselIndex - 1 + carousels.length) % carousels.length; // Passer au précédent
            const containerWidth = carousels[0].getBoundingClientRect().width;
            carouselContainer2.style.transition = ""; // Activer la transition
            carouselContainer2.style.transform = `translateX(-${currentCarouselIndex * containerWidth}px)`; // Repositionner
        });

        // Gestion des autres carrousels
        const allCarousels = document.querySelectorAll('.carousel_photo');
        allCarousels.forEach(carousel => {
            const track = carousel.querySelector('.carousel-track');
            const slides = Array.from(track.children);
            const prevButton = carousel.querySelector('.carousel-button.prev');
            const nextButton = carousel.querySelector('.carousel-button.next');

            let currentIndex2 = 0;

            function updateTrack() {
                const slideWidth = slides[0].getBoundingClientRect().width;
                track.style.transition = "none"; // Désactiver les transitions pour le redimensionnement
                track.style.transform = `translateX(-${currentIndex2 * slideWidth}px)`; // Repositionner correctement
            }

            // Écouteur pour redimensionnement de la fenêtre
            window.addEventListener('resize', () => {
                updateTrack(); // Mise à jour basée sur l'index actuel
            });

            nextButton.addEventListener('click', () => {
                currentIndex2 = (currentIndex2 + 1) % slides.length; // Passer au suivant
                if (window.innerWidth < 800) {
                    if (currentIndex2 > slides.length - 1) { currentIndex2 = 0; }
                } else if (window.innerWidth < 1000) {
                    if (currentIndex2 > slides.length - 2) { currentIndex2 = 0; }
                } else {
                    if (currentIndex2 > slides.length - 3) { currentIndex2 = 0; }
                }
                const slideWidth = slides[0].getBoundingClientRect().width;
                track.style.transition = ""; // Activer la transition
                track.style.transform = `translateX(-${currentIndex2 * slideWidth}px)`; // Repositionner
            });

            prevButton.addEventListener('click', () => {
                currentIndex2 = (currentIndex2 - 1 + slides.length) % slides.length; // Passer au précédent
                if (window.innerWidth < 800) {
                    if (currentIndex2 == slides.length - 1) { currentIndex2 = slides.length - 1; }
                } else if (window.innerWidth < 1000) {
                    if (currentIndex2 == slides.length - 1) { currentIndex2 = slides.length - 2; }
                } else {
                    if (currentIndex2 == slides.length - 1) { currentIndex2 = slides.length - 3; }
                }
                const slideWidth = slides[0].getBoundingClientRect().width;
                track.style.transition = ""; // Activer la transition
                track.style.transform = `translateX(-${currentIndex2 * slideWidth}px)`; // Repositionner
            });

            updateTrack(); // Initialiser l'affichage
        });

        // Initialisation de l'affichage
        updateCarouselDisplay();




    </script>
</body>

</html>