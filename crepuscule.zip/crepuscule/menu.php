<ul class="menu">
    <li><a href="index.php">Accueil </a></li>
    <li><a href="news.php">News </a></li>
    <li><a href="photo.php">Photos </a></li>
    <li><a href="contact.php">Contact </a></li>
    <li><a href="agenda.php">Agenda </a></li>
    <li><a href="tarif.php">Tarif </a></li>
</ul>