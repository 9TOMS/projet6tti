<div class="news_poste marge">
    <div class="top">
        <div class="gauche">Text</div>
        <div class="droite">Date</div>
    </div>
    <div class="imagenews" class="pdfnews-container" class="calendar-container iframe-shadow">

        <?php //<iframe src="images/Halloween_stages.pdf#toolbar=0" overflow-y="auto" overflow-x="auto" class="pdfnews" overflow= "hidden"></iframe> ?>
        <iframe
            src="https://docs.google.com/presentation/d/e/2PACX-1vThkESQUrHo13pkfQuSwoIK68z7zQ_W70Itwx9tbWfOz8L31PvrXulJv3YkwvPDfy20Rrln-0Epmsqi/embed?start=false&loop=false&delayms=3000"
            frameborder="0" class="pdfnews" overflow="hidden" allowfullscreen="true"
            mozallowfullscreen="true" webkitallowfullscreen="true" width="100%" height="250px"></iframe>
    </div>
    <div class="bas">
        <div class="coeur">❤️</div>
        <div class="partage">➤</div>
    </div>

    <div class="commentaire">
        <div class="commentaire-item">
            <div class="avatar"></div>
            <div class="texte">Trop beau le cheval</div>
            <div class="date">Date</div>
        </div>
        <div class="commentaire-item">
            <div class="avatar"></div>
            <div class="texte">Hâte de venir rencontrer ces chevaux...</div>
            <div class="date">Date</div>
        </div>
        <div class="commentaire-item">
            <div class="avatar"></div>
            <div class="texte">Comment on s'inscrit</div>
            <div class="date">Date</div>
        </div>

        <div class="ecrire-commentaire">
            <input type="text" placeholder="Écrire un commentaire...">
            <button>➤</button>
        </div>
    </div>
</div>