<?php
$bdd = mysqli_connect('localhost','root','','jeunombre');
session_start();
if(isset($_SESSION['pseudo'])){
    $Pseudo = $_SESSION['pseudo'];
}
else {
    $Pseudo = 'Pseudo';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css.css"/>
    <script src="java.js"></script>
    <title>Resultat</title>
</head>
<body>
    <div id="entete">
        <p>Cette partie t'a plu ?</p>
    </div>
    <div id ="restart" onclick="recommencer()">
         <p>C'est parti pour un nouvel essai !</p>
    </div>
    <div id ="quitter" onclick="partir()">
         <p>Au revoir (snif)</p>
    </div>
    <div id='meilleur_score'>
        <p>Voici tes meilleurs scores</p>
        <table id="fin">
            <tr>
                <th class="fin2">Pseudo</th>
                <th class="fin2">NbrCoups</th>
                <th class="fin2">Temps</th>
            </tr>
            <?php
            $requete = "SELECT `Pseudo`, `NbrCoups`, `Temps` FROM `stat` WHERE pseudo = '$Pseudo' ORDER BY temps";
            $resultat = mysqli_query($bdd, $requete);
            
            if ($resultat) {
                while ($row = mysqli_fetch_assoc($resultat)) {
                    echo "<tr>
                            <td class='fin2'>{$row['Pseudo']}</td>
                            <td class='fin2'>{$row['NbrCoups']}</td>
                            <td class='fin2'>{$row['Temps']}</td>
                        </tr>";
                }
                mysqli_free_result($resultat);
            }
            mysqli_close($bdd); 
            ?>
        </table>
    </div>
</body>
</html>