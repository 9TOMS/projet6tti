<?php
date_default_timezone_set('Europe/Brussels');
$date_depart = date("H:i:s");

session_start();
if (isset($_SESSION['pseudo'])) {
    $Pseudo = $_SESSION['pseudo'];
} else {
    $Pseudo = 'Pseudo';
}

$jour = date('d');
$mois = date('m');
$annee = date('Y');

if ((isset($_POST['enregistrer'])) && ($fin=true)) {
    $nbrcoups=5;
    $temps='10:10:10';
    $bdd = mysqli_connect("localhost", "root", "", "jeunombre");
    mysqli_set_charset($bdd, "utf8");
    $requete = "INSERT INTO `stat`(`Pseudo`, `NbrCoups`,`Temps`) VALUES (?,?,?)";
    $prepa = mysqli_stmt_init($bdd);
    mysqli_stmt_prepare($prepa, $requete);
    mysqli_stmt_bind_param($prepa, 'sid', $Pseudo, $nbrcoups, $temps);
    $resultat = mysqli_stmt_execute($prepa);
    mysqli_stmt_close($prepa);

    header('Location: resultat.php');
} else {
    $fin=false;
}

?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css.css" />
    <script src="java.js"></script>
    <title>Trouve le nombre</title>
</head>

<body>
    <div id="entete">
        <div id="text1">
            Bonjour <?php echo $Pseudo ?>, nous sommes le <?php echo $jour . '-' . $mois . '-' . $annee ?><br>
            Jeu de recherche d'un nombre choisit aléatoirement par le programe</div>
    </div>
    <div id="intituler">
        <script>
            document.getElementById('intituler').innerHTML = "Vous devez trouver un nombre entre 1 et 1024";
        </script>
    </div>

    <br>

    <div id="input"> 
        <input type="number" id="nbr" placeholder="Entrez un nombre">
        <input type="submit" value="Tester" onclick="test()">
    </div>

    <p id="heure_de_depart">Heure de départ : <?php echo $date_depart; ?></p>
    <div class="heure_actuelle">Heure actuelle : <span id="heure_actuelle"><?php echo $date_depart; ?></span></div>

    <p id="duree_partie"></p>
    <div id="pied">
        <div id="text2">
            <div id="text3"></div>
            <form method="post" id="form_enregistrer">
                <button name="enregistrer" id="enregistrer">Enregistrer la partie</button>
            </form>
        </div>
    </div>
</body>

</html>