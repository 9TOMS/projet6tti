<?php
session_start();
$connexion = mysqli_connect('localhost', 'root', '', 'jeunombre');

$sql = "SELECT * FROM `stat` ORDER BY `Temps` ASC LIMIT 5";
$result = mysqli_query($connexion, $sql);
 


    if (isset($_POST['pseudoj'])) {
        $pseudo = mysqli_real_escape_string($connexion, $_POST['pseudo']);

        header("Location: jeu.php");
        $_SESSION['pseudo'] = $pseudo;
    }

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css.css"/>
    <script src="java.js"></script>
    <title>jeu nombre</title>
</head>
<body>
    <div id="entete">
        <div id="text1">Jeu de recherche d'un nombre choisit aléatoirement par le programe</div>
    </div>
    <br>
    <form  method="post">
        <div id="input"> 
            <label for="pseudo">Quel est votre pseudo : </label>
            <input type="text" name="pseudo" id="pseudo"  required>
            <button name="pseudoj" type="submit">envoyer</button>
        </div>
    </form>
    <div id="piedindex">
        <div id="text2">Ce n'est pas pour te mettre la pression, mais voici les meilleurs scores</div>
        <table>
            <thead>
                <tr>
                    <th>Pseudo</th>
                    <th>Nbr de Coups</th>
                    <th>Temps</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['Pseudo']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['NbrCoups']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['Temps']) . "</td>";
                        echo "</tr>";
                    }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>